num1 = int(input("Введите 1 число: "))


num2 = float(input("Введите 1 число: "))


num3 = int(input("Введите 1 число: "))


print("Result:", num1*num2*num3)
