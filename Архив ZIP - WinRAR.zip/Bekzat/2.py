num1 = int(input("Введите 1 число: "))

num2 = int(input("Введите 2 число: "))


num1*=5

print("Result:", num1 + num2)
print("Result:", num1 - num2)
print("Result:", num1 / num2)
print("Result:", num1 * num2)
print("Result:", num1 ** num2)
print("Result:", num1 // num2)

word = "Hi"
print(word * 2)

word = True 
