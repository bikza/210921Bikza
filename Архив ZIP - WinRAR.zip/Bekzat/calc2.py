x = int(input("Первое число: "))
math = input("Операция: ")
y = int(input("Второе число: "))

if x%2==0:print('4et')
if y%2==0:print('4et')

if math == '+':
	print(x, " + ", y, " = ", (x + y))
elif math == '-':
	print(x, " - ", y, " = ", (x - y))
elif math == '*':
	print(x, " * ", y, " = ", (x * y))
elif math == '/':
	print(x, " / ", y, " = ", (x / y))
else:
	print("Неверная операция")

