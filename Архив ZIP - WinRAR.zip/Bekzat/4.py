num1 = int(input("Введите 1 число: "))

num2 = int(input("Введите 1 число: "))
num3 = int(input("Введите 1 число: "))


print("Result:", num1 + num2+num3)
print("Result:", num1 - num2-num3)
print("Result:", num1 / num2/num3)
print("Result:", num1 * num2/num3)
print("Result:", num1 ** num2**num3)
