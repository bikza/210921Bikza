number = 5 # int

digit = -4.54356876 # float
word = "Результат:" # string
boolean = True # bool

str_num = '5' # string

# print(word + str(digit))

print(word + str(number + int(str_num)))

del number

number = 7
print("Результат:", number)
