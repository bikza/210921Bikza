surname = input("Введите свою фамилию? ")
surname *= 3
print(surname)
