a = int (input("VVedite chislo:"))
b = int (input("VVedite chislo:"))

def even_or_odd(a):
    if a % 2 == 0:
        print('Четное число')       
    elif b % 2 == 0:
        print('Четное число')
    else:
        print('Нечентное число')
