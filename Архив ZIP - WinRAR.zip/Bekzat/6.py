user_data = int(input("Введите число: "))

isHappy = True

if isHappy or user_data == 6:
    print("User is happy")
elif user_data == 5:
    print("Number is 5")
elif user_data == 7:
    print("Number is 7")
else:
    print("User is unhappy")

# if user_data != 5:
#     print("Мы на месте")
#     if user_data > 6:
#         print("Number is bigger than 5")
